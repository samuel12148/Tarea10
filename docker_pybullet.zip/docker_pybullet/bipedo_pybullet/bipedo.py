import pybullet as p
import pybullet_data
import time
import os

p.connect(p.GUI)
p.setGravity(0, 0, -9.8)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
p.setAdditionalSearchPath(".")

urdf_path = os.path.join("biped", "biped2d.urdf")

if not os.path.exists(urdf_path):
    raise FileNotFoundError(f"No se encontró el archivo: {urdf_path}")

robot = p.loadURDF(urdf_path, [0, 0, 2], useFixedBase=False)

joints = [0, 1, 2, 3]
kp = 100
kd = 10
target_angles = [0.5, -0.5, 0.3, -0.3]

for _ in range(1000):
    for i, joint in enumerate(joints):
        p.setJointMotorControl2(
            robot, joint, p.POSITION_CONTROL,
            targetPosition=target_angles[i],
            positionGain=kp, velocityGain=kd
        )
    p.stepSimulation()
    time.sleep(10/240)
